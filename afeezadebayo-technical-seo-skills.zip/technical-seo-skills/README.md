# Technical SEO Skills-md by Afeez Adebayo

16 skills, one folder each, ready to install.

Source: https://afeezadebayo.com/skills-md/marketing/technical-seo/
Website: https://afeezadebayo.com
LinkedIn: https://www.linkedin.com/in/afeez-adebayo/
X: https://x.com/za_icon
Licence: CC BY 4.0. Credit Afeez Adebayo and link to the source page.

## Install
- Claude Code: copy every skill folder in this folder into ~/.claude/skills/ (or .claude/skills/ in a project).
- Codex and other Agent Skills tools: copy them into .agents/skills/ or the tool's skills folder.
- Claude apps: upload skills one at a time using the single-skill .zip on each skill's page.

## Skills
- technical-seo-audit: Technical SEO Audit
- crawlability-indexation-audit: Crawlability and Indexation Audit
- robots-directives: Robots.txt and Robots Directives
- xml-sitemaps: XML Sitemaps
- canonicalization: Canonicalization and Duplicate Content
- redirects-status-codes: Redirects and HTTP Status Codes
- site-migration: Site Migration SEO
- core-web-vitals: Core Web Vitals and Page Experience
- javascript-seo: JavaScript SEO and Rendering
- structured-data: Structured Data and Schema Markup
- internal-linking: Internal Linking and Site Architecture
- log-file-analysis: Log File Analysis for SEO
- faceted-navigation-parameters: Faceted Navigation and URL Parameters
- lcp-optimisation: LCP Optimisation
- inp-optimisation: INP Optimisation
- cls-optimisation: CLS Optimisation
